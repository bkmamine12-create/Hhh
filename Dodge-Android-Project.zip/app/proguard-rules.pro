# Dodge - ProGuard / R8 rules
# The game uses no reflection-based libraries, so the default
# Android/Kotlin shrink rules are sufficient. Kept intentionally minimal.

-keepattributes SourceFile,LineNumberTable
-dontnote
