package com.dodge.game

import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.dodge.game.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), GameView.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var scoreManager: ScoreManager
    private lateinit var soundManager: SoundManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Gameplay is finger-drag based; keep the screen from sleeping mid-run.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        scoreManager = ScoreManager(this)
        soundManager = SoundManager(this)

        binding.gameView.listener = this
        binding.gameView.attachSound(soundManager)

        binding.startBestText.text = getString(R.string.best_label) + " \u00B7 " + scoreManager.bestScore
        binding.startButton.setOnClickListener { beginRun() }
        binding.playAgainButton.setOnClickListener { beginRun() }
    }

    private fun beginRun() {
        binding.gameOverOverlay.visibility = View.GONE
        binding.startOverlay.visibility = View.GONE
        binding.scoreText.text = "0"
        binding.scoreText.visibility = View.VISIBLE
        binding.gameView.startGame()
    }

    // -----------------------------------------------------------
    // GameView.Listener — called back on the main thread
    // -----------------------------------------------------------

    override fun onScoreChanged(score: Int) {
        binding.scoreText.text = score.toString()
    }

    override fun onGameOver(finalScore: Int) {
        val isNewBest = scoreManager.submit(finalScore)

        flashHit()
        vibrateHit()

        binding.scoreText.visibility = View.GONE
        binding.finalScoreText.text = finalScore.toString()
        binding.bestScoreText.text = scoreManager.bestScore.toString()
        binding.newBestBadge.visibility = if (isNewBest) View.VISIBLE else View.GONE

        showGameOverCard()
    }

    private fun showGameOverCard() {
        binding.gameOverOverlay.alpha = 0f
        binding.gameOverOverlay.visibility = View.VISIBLE
        binding.gameOverOverlay.animate()
            .alpha(1f)
            .setDuration(220)
            .setStartDelay(120)
            .start()

        val card = binding.gameOverCard
        card.alpha = 0f
        card.scaleX = 0.85f
        card.scaleY = 0.85f
        card.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(320)
            .setStartDelay(150)
            .setInterpolator(OvershootInterpolator(1.6f))
            .start()
    }

    private fun flashHit() {
        binding.hitFlash.animate().cancel()
        binding.hitFlash.alpha = 0.55f
        binding.hitFlash.animate().alpha(0f).setDuration(280).start()
    }

    private fun vibrateHit() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(60)
                }
            }
        } catch (e: Exception) {
            // Vibration is a nice-to-have; it should never crash the game.
        }
    }

    // -----------------------------------------------------------
    // Lifecycle
    // -----------------------------------------------------------

    override fun onPause() {
        super.onPause()
        binding.gameView.endIfPlaying()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.gameView.release()
    }
}
