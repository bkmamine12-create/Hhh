package com.dodge.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * The whole game lives here: a SurfaceView driven by a dedicated thread
 * so drawing never waits on the main/UI thread, which is what keeps
 * this smooth on low-end devices. All gameplay state (enemy list,
 * score, difficulty) is owned exclusively by that thread; the Activity
 * only ever talks to it through [startGame], [endIfPlaying] and the
 * [Listener] callbacks, which keeps this free of cross-thread races.
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    interface Listener {
        fun onScoreChanged(score: Int)
        fun onGameOver(finalScore: Int)
    }

    var listener: Listener? = null

    fun attachSound(soundManager: SoundManager) {
        sound = soundManager
    }

    // ---------------------------------------------------------------
    // Thread / surface lifecycle
    // ---------------------------------------------------------------

    private var gameThread: Thread? = null
    @Volatile private var running = false

    private val surfaceReadyLock = Object()
    private var surfaceReady = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var sound: SoundManager? = null

    override fun surfaceCreated(holder: SurfaceHolder) {
        density = resources.displayMetrics.density
        synchronized(surfaceReadyLock) { surfaceReady = true }
        if (gameThread?.isAlive != true) {
            running = true
            gameThread = Thread(this, "DodgeGameThread").also { it.start() }
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        screenW = width.toFloat()
        screenH = height.toFloat()
        val p = player
        if (p == null) {
            player = Player(screenW / 2f, screenH - dp(90f), dp(PLAYER_SIZE_DP))
        } else {
            p.y = screenH - dp(90f)
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        synchronized(surfaceReadyLock) { surfaceReady = false }
        running = false
        try {
            gameThread?.join(500)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        gameThread = null
    }

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ---------------------------------------------------------------
    // Public control surface (called from the Activity / main thread)
    // ---------------------------------------------------------------

    /** Requests a fresh run. The actual reset happens on the game thread. */
    fun startGame() {
        pendingStart = true
    }

    /** Ends the current run if one is in progress, e.g. when the app is backgrounded. */
    fun endIfPlaying() {
        if (playing) {
            playing = false
            listener?.onGameOver(score)
        }
    }

    fun release() {
        sound?.release()
    }

    // ---------------------------------------------------------------
    // Touch
    // ---------------------------------------------------------------

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!playing) return true
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            player?.let {
                val half = it.size / 2f
                it.targetX = event.x.coerceIn(half, screenW - half)
            }
        }
        return true
    }

    // ---------------------------------------------------------------
    // Playfield state (owned by the game thread)
    // ---------------------------------------------------------------

    private var screenW = 0f
    private var screenH = 0f
    private var density = 1f
    private var player: Player? = null

    private val activeEnemies = ArrayList<Enemy>()
    private val enemyPool = ArrayList<Enemy>()

    @Volatile private var playing = false
    @Volatile private var score = 0
    private var elapsedSeconds = 0f
    private var spawnTimer = 0f
    private var lastFrameNanos = 0L
    @Volatile private var pendingStart = false

    // --- Difficulty tuning (all in dp/sec so it scales across screen densities) ---
    private val baseSpeedDp = 220f
    private val speedGrowthPerSec = 6.5f
    private val maxSpeedDp = 900f
    private val baseSpawnInterval = 1.05f
    private val minSpawnInterval = 0.32f
    private val spawnDecayPerSec = 0.012f
    private val enemyRadiusDp = 16f

    companion object {
        private const val PLAYER_SIZE_DP = 42f
        private const val TARGET_FPS = 60
        private const val FRAME_BUDGET_NANOS = 1_000_000_000L / TARGET_FPS
    }

    // ---------------------------------------------------------------
    // Game loop
    // ---------------------------------------------------------------

    override fun run() {
        while (running) {
            val ready = synchronized(surfaceReadyLock) { surfaceReady }
            if (!ready) {
                sleepQuiet(16)
                continue
            }

            val frameStart = System.nanoTime()

            if (pendingStart) {
                pendingStart = false
                resetRun()
                playing = true
                lastFrameNanos = frameStart
            }

            var dt = (frameStart - lastFrameNanos) / 1_000_000_000f
            lastFrameNanos = frameStart
            dt = dt.coerceIn(0f, 0.05f) // clamp so a stall never causes a huge jump

            if (playing) update(dt)

            val canvas = try {
                holder.lockCanvas()
            } catch (e: Exception) {
                null
            }
            if (canvas != null) {
                try {
                    draw(canvas)
                } finally {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        // Surface can disappear mid-teardown; safe to ignore.
                    }
                }
            }

            val frameNanos = System.nanoTime() - frameStart
            val sleepMillis = (FRAME_BUDGET_NANOS - frameNanos) / 1_000_000
            if (sleepMillis > 0) sleepQuiet(sleepMillis)
        }
    }

    private fun sleepQuiet(millis: Long) {
        try {
            Thread.sleep(millis)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private fun resetRun() {
        activeEnemies.forEach { recycle(it) }
        activeEnemies.clear()
        score = 0
        elapsedSeconds = 0f
        spawnTimer = 0f
        player?.let {
            it.x = screenW / 2f
            it.targetX = it.x
        }
        mainHandler.post { listener?.onScoreChanged(0) }
    }

    private fun update(dt: Float) {
        val p = player ?: return
        elapsedSeconds += dt

        // Ease the player toward the last touch position (frame-rate independent).
        p.x += (p.targetX - p.x) * min(1f, dt * 14f)

        // --- Spawning, with an interval that shrinks over time ---
        spawnTimer += dt
        val spawnInterval = max(minSpawnInterval, baseSpawnInterval - spawnDecayPerSec * elapsedSeconds)
        if (spawnTimer >= spawnInterval) {
            spawnTimer = 0f
            spawnEnemy()
        }

        // --- Advance, collide, and cull enemies ---
        val currentSpeed = min(maxSpeedDp, baseSpeedDp + speedGrowthPerSec * elapsedSeconds) * density
        val iterator = activeEnemies.iterator()
        while (iterator.hasNext()) {
            val e = iterator.next()
            e.y += currentSpeed * dt

            if (circleIntersectsSquare(e, p)) {
                playing = false
                sound?.playHit()
                val finalScore = score
                mainHandler.post { listener?.onGameOver(finalScore) }
                return
            }

            if (e.y - e.radius > screenH) {
                iterator.remove()
                recycle(e)
                score += 1
                sound?.playScore()
                val newScore = score
                mainHandler.post { listener?.onScoreChanged(newScore) }
            }
        }
    }

    private fun spawnEnemy() {
        val radius = dp(enemyRadiusDp)
        if (screenW <= radius * 2f) return
        val x = Random.nextFloat() * (screenW - radius * 2f) + radius
        val speed = min(maxSpeedDp, baseSpeedDp + speedGrowthPerSec * elapsedSeconds) * density
        val enemy = if (enemyPool.isNotEmpty()) {
            enemyPool.removeAt(enemyPool.size - 1).also { it.reset(x, -radius, radius, speed) }
        } else {
            Enemy(x, -radius, radius, speed)
        }
        activeEnemies.add(enemy)
        sound?.playSpawn()
    }

    private fun recycle(enemy: Enemy) {
        if (enemyPool.size < 40) enemyPool.add(enemy)
    }

    private fun circleIntersectsSquare(e: Enemy, p: Player): Boolean {
        val closestX = e.x.coerceIn(p.left(), p.right())
        val closestY = e.y.coerceIn(p.top(), p.bottom())
        val dx = e.x - closestX
        val dy = e.y - closestY
        return (dx * dx + dy * dy) < (e.radius * e.radius)
    }

    // ---------------------------------------------------------------
    // Drawing
    // ---------------------------------------------------------------

    private val backgroundColor = Color.parseColor("#0A0A0C")
    private val playerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F5F5F7") }
    private val enemyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF3B3B") }
    private val playerRect = RectF()

    private fun draw(canvas: Canvas) {
        canvas.drawColor(backgroundColor)

        val p = player
        if (p != null) {
            playerRect.set(p.left(), p.top(), p.right(), p.bottom())
            val corner = dp(8f)
            canvas.drawRoundRect(playerRect, corner, corner, playerPaint)
        }

        for (e in activeEnemies) {
            canvas.drawCircle(e.x, e.y, e.radius, enemyPaint)
        }
    }

    private fun dp(value: Float): Float = value * density
}
