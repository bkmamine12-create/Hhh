package com.dodge.game

/**
 * The player-controlled square. [x] and [y] mark the square's center in
 * pixels; [size] is the side length in pixels.
 */
class Player(var x: Float, var y: Float, val size: Float) {

    /** Latest horizontal finger position; [x] eases toward this every frame. */
    var targetX: Float = x

    private val half: Float get() = size / 2f

    fun left(): Float = x - half
    fun right(): Float = x + half
    fun top(): Float = y - half
    fun bottom(): Float = y + half
}
