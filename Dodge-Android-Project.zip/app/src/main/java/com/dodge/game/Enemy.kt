package com.dodge.game

/**
 * A falling red ball. [x], [y] mark the circle's center in pixels and
 * [radius] its radius in pixels. [speed] is in pixels/second and grows
 * as a run goes on. Instances are recycled by [GameView] instead of
 * being reallocated every spawn, to keep the game loop garbage-free.
 */
class Enemy(var x: Float, var y: Float, var radius: Float, var speed: Float) {

    fun reset(x: Float, y: Float, radius: Float, speed: Float) {
        this.x = x
        this.y = y
        this.radius = radius
        this.speed = speed
    }
}
