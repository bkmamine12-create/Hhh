package com.dodge.game

import android.content.Context

/**
 * Thin wrapper around SharedPreferences for the one piece of state the
 * game remembers between launches: the best score. Purely local — no
 * account, no network, no backend.
 */
class ScoreManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var bestScore: Int
        get() = prefs.getInt(KEY_BEST_SCORE, 0)
        private set(value) {
            prefs.edit().putInt(KEY_BEST_SCORE, value).apply()
        }

    /** Updates the stored best score if [score] beats it. Returns true on a new best. */
    fun submit(score: Int): Boolean {
        if (score > bestScore) {
            bestScore = score
            return true
        }
        return false
    }

    companion object {
        private const val PREFS_NAME = "dodge_prefs"
        private const val KEY_BEST_SCORE = "best_score"
    }
}
