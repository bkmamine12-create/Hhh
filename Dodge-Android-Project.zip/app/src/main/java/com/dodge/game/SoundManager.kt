package com.dodge.game

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

/**
 * Loads the game's three short sound effects once and plays them with
 * SoundPool, which is built for many overlapping, very short clips
 * (unlike MediaPlayer, which is meant for longer-form audio). Playing a
 * sound before it finishes loading is a documented no-op, so no extra
 * "is it ready" bookkeeping is needed here.
 */
class SoundManager(context: Context) {

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val spawnId = soundPool.load(context, R.raw.spawn, 1)
    private val scoreId = soundPool.load(context, R.raw.score, 1)
    private val hitId = soundPool.load(context, R.raw.hit, 1)

    fun playSpawn() = play(spawnId, 0.18f)
    fun playScore() = play(scoreId, 0.35f)
    fun playHit() = play(hitId, 0.7f)

    private fun play(soundId: Int, volume: Float) {
        soundPool.play(soundId, volume, volume, 1, 0, 1f)
    }

    fun release() {
        soundPool.release()
    }
}
