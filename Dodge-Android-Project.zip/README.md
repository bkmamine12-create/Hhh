# Dodge

A minimalist endless dodger for Android. Drag left/right to keep a white
square away from red balls falling from the top of the screen. Every
ball you avoid scores a point; the game gets faster and busier the
longer you survive. Best score is saved on-device — no account, no
network, no backend.

## What's in this project

```
app/src/main/java/com/dodge/game/
  MainActivity.kt    UI shell: start screen, HUD, game-over card, hit flash, vibration
  GameView.kt         The game itself — SurfaceView + dedicated thread game loop,
                       touch control, spawning/difficulty curve, collision detection
  Player.kt / Enemy.kt Plain data holders for the two entities on screen
  ScoreManager.kt      SharedPreferences wrapper that persists the best score
  SoundManager.kt      SoundPool wrapper for the three sound effects

app/src/main/res/
  layout/activity_main.xml   Start screen, score HUD, hit-flash overlay, game-over card
  values/                    Dark palette, strings, fullscreen theme
  drawable/                  Buttons, card background, adaptive app icon
  raw/spawn.wav, score.wav, hit.wav   Synthesized sound effects (a few KB each)

.github/workflows/build-apk.yml   Builds real APKs automatically on GitHub (see below)
```

Everything is hand-written, dependency-light (just androidx core-ktx +
appcompat), and uses no libraries beyond the Android platform — that's
what keeps the APK small and low-end devices smooth.

## Getting the installable APK

This project was built and verified in an environment with no Android
SDK and no internet access, so it could be written and checked line by
line but not compiled into a binary there. The fastest way to get an
actual `.apk` file is to let GitHub's build servers do it — free, and
no Android tooling to install:

1. Create a new repository on [github.com](https://github.com) and
   upload this whole folder to it (drag-and-drop the files in the
   GitHub web UI works fine, or `git push` if you're comfortable with
   git).
2. Open the repo's **Actions** tab. A workflow called **"Build Dodge
   APK"** runs automatically on the first push (or click **"Run
   workflow"** to trigger it manually).
3. Wait for the green checkmark (a couple of minutes), open the
   finished run, and download the **Dodge-release-apk** artifact from
   the **Artifacts** section at the bottom of the page. Unzip it — the
   `.apk` inside installs directly on your phone.

On your phone, open the downloaded APK to install it (you may need to
allow "install unknown apps" for whichever app you downloaded it
through — a one-time Android prompt).

**Alternative:** open the folder in Android Studio and press Run — it
will offer to generate the Gradle wrapper automatically and build/run
straight to a connected device or emulator.

If a build ever fails (CI or Android Studio), paste the error output
back and it can be fixed directly — nothing here is expected to fail,
but if it does, that log is exactly what's needed to fix it fast.

## Tuning the game

All difficulty numbers live at the top of `GameView.kt`:

- `baseSpeedDp` / `speedGrowthPerSec` / `maxSpeedDp` — how fast balls
  fall, and how quickly that ramps up
- `baseSpawnInterval` / `minSpawnInterval` / `spawnDecayPerSec` — how
  often balls spawn, and how quickly that ramps up
- `enemyRadiusDp` / `PLAYER_SIZE_DP` — sizes of the ball and the player

## License

Free to use, modify, and ship as your own.
